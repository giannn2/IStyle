document.addEventListener("DOMContentLoaded", () => {
    const productCards = document.querySelectorAll(".product-card");

    if (productCards.length === 0) {
        return; // Non fare nulla se il carrello è vuoto
    }

    const totalPrice = document.querySelector(".ViewTotal");


    productCards.forEach(card => {
        const id = card.dataset.id;
        const addBtn = card.querySelector(".btnAdd");
        const removeBtn = card.querySelector(".btnRemove");
        const quantityDisplay = card.querySelector(".quantity-controls p");

        addBtn.addEventListener("click", () => {
            fetch('/IStyle/cart?action=add&id=' + id)
                .then(res => res.json())
                .then(data => {
                    quantityDisplay.textContent = data.product.quantityInCart;
                    totalPrice.innerHTML = "<strong>Totale: </strong>" + data.cartTotal.toFixed(2);
                });
        });

        removeBtn.addEventListener("click", () => {
            fetch('/IStyle/cart?action=remove&id=' + id)
                .then(res => res.json())
                .then(data => {
                    let newQty = parseInt(quantityDisplay.textContent) - 1;
                    if (newQty > 0)
                        quantityDisplay.textContent = newQty;
                    else
                        card.remove();


                    totalPrice.innerHTML = "<strong>Totale: </strong>" + data.total.toFixed(2);
                });
        });
    });
});
