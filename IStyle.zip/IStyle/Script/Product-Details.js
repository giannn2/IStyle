
tsParticles.load("tsparticles", {
    particles: {
        number: { value: 80 },
        color: { value: "#E75919" },
        shape: { type: "circle" },
        size: { value: { min: 2, max: 5 } },
        move: { enable: true, speed: 1.5 }
    }
});

// Zoom functionality
document.addEventListener('DOMContentLoaded', function() {
    const mainImg      = document.getElementById('productImage');
    const thumbnails   = document.querySelectorAll('.miniatura');
    const imageWrapper = document.getElementById('imageWrapper');
    const lens         = document.getElementById('lens');
    const popover      = document.getElementById('zoomPopover');

    function updateBackgroundSize() {
        const rect = mainImg.getBoundingClientRect();
        const cx = popover.offsetWidth / lens.offsetWidth;
        const cy = popover.offsetHeight / lens.offsetHeight;
        popover.style.backgroundSize = `${rect.width * cx}px ${rect.height * cy}px`;
    }

    popover.style.backgroundImage = `url('${mainImg.src}')`;
    if (mainImg.complete) {
        updateBackgroundSize();
    } else {
        mainImg.onload = updateBackgroundSize;
    }

    thumbnails.forEach(thumb => {
        thumb.addEventListener('mouseenter', () => {
            document.querySelectorAll('.miniatura.active').forEach(el => el.classList.remove('active'));
            thumb.classList.add('active');

            const fullUrl = thumb.getAttribute('data-full');
            mainImg.src = fullUrl;
            popover.style.backgroundImage = `url('${fullUrl}')`;

            if (mainImg.complete) {
                updateBackgroundSize();
            } else {
                mainImg.onload = updateBackgroundSize;
            }
        });
    });

    window.addEventListener('resize', updateBackgroundSize);

    imageWrapper.addEventListener('mousemove', moveLens);
    imageWrapper.addEventListener('mouseenter', () => {
        lens.style.display    = 'block';
        popover.style.display = 'block';
    });
    imageWrapper.addEventListener('mouseleave', () => {
        lens.style.display    = 'none';
        popover.style.display = 'none';
    });

    function moveLens(e) {
        const b = mainImg.getBoundingClientRect();
        let x = e.clientX - b.left  - lens.offsetWidth  / 2;
        let y = e.clientY - b.top   - lens.offsetHeight / 2;
        x = Math.max(0, Math.min(x, b.width  - lens.offsetWidth));
        y = Math.max(0, Math.min(y, b.height - lens.offsetHeight));
        lens.style.left = x + 'px';
        lens.style.top  = y + 'px';

        const fx = popover.offsetWidth  / lens.offsetWidth;
        const fy = popover.offsetHeight / lens.offsetHeight;
        popover.style.backgroundPosition = `-${x * fx}px -${y * fy}px`;
    }
});

// Gestione stelle di valutazione
const stars = document.querySelectorAll('.star-rating label');
stars.forEach(star => {
    star.addEventListener('click', function() {
        const ratingInput = this.previousElementSibling;
        ratingInput.checked = true;
        const ratingValue = parseInt(ratingInput.value);
        resetStars();
        highlightStars(ratingValue);
    });
});

function resetStars() {
    document.querySelectorAll('.star-rating label').forEach(star => {
        star.style.color = '#ddd';
    });
}

function highlightStars(count) {
    const stars = document.querySelectorAll('.star-rating label');
    for (let i = 0; i < count; i++) {
        stars[stars.length - 1 - i].style.color = '#FFD700';
    }
}




/*RIchiesta AJAX per selezione del colore*/
document.addEventListener('DOMContentLoaded', function() 
{

    // --- 1. Leggi i dati dinamici dal tag <body> ---
    const body = document.querySelector('body');
    const productID = body.dataset.productId;
    const contextPath = body.dataset.contextPath;

    // --- 2. Logica per la selezione del colore ---
    const colorOptions = document.querySelectorAll('.colore-option');
    const modelSelect = document.getElementById('modelSelect');

    if (colorOptions.length > 0 && modelSelect) {
        colorOptions.forEach(option => {
            option.addEventListener('click', function() {
                const selectedColor = this.dataset.color;

                // Evidenzia il colore selezionato
                colorOptions.forEach(el => el.classList.remove('active'));
                this.classList.add('active');

                // Costruisci l'URL usando i dati letti dal body
                const url = `${contextPath}/product?action=selectProductData&IDProdotto=${productID}&Color=${encodeURIComponent(selectedColor)}`;

                // Esegui la richiesta AJAX
                fetch(url)
                    .then(response => {
                        if (!response.ok) {
                            throw new Error('Errore di rete o del server.');
                        }
                        return response.json();
                    })
                    .then(result => {

                        if (result.success && result.data) {
                            // Svuota e popola il menu dei modelli
                            modelSelect.innerHTML = '';
                            if (result.data.length > 0) {
                                result.data.forEach(model => {
                                    const optionElement = document.createElement('option');
                                    optionElement.value = model;
                                    optionElement.textContent = model;
                                    modelSelect.appendChild(optionElement);
                                });
                            } else {
                                const optionElement = document.createElement('option');
                                optionElement.disabled = true;
                                optionElement.textContent = 'Nessun modello disponibile';
                                modelSelect.appendChild(optionElement);
                            }
                        } else {
                            console.error('La servlet ha restituito un errore:', result.message);
                            modelSelect.innerHTML = '<option disabled>Errore nel caricamento</option>';
                        }
                    })
                    .catch(error => {
                        console.error('Errore nella richiesta AJAX:', error);
                        modelSelect.innerHTML = '<option disabled>Errore di connessione</option>';
                    });
            });
        });
    }
})





/*Funzioni per la sidebar relativa al carrello*/

function showSidebar(data, contextPath) 
{
    const overlay = document.getElementById('cart-sidebar-overlay');
    const sidebar = document.getElementById('cart-sidebar');

    console.log(data);


    // --- Popola i dati ---
    document.getElementById('sidebar-product-image').src = `${contextPath}/images/prodotti/${data.product.ImagesPaths[0]}`;
    document.getElementById('sidebar-product-name').textContent = data.product.name;
    document.getElementById('sidebar-product-quantity').textContent = `Quantità: ${data.product.quantityInCart}`;
    document.getElementById('sidebar-cart-quantity').textContent = data.quantityOfProductInCart;
    document.getElementById('sidebar-cart-total').textContent = `€ ${parseFloat(data.cartTotal).toFixed(2)}`;

    // --- Aggiungi i listener per la chiusura ---
    document.getElementById('sidebar-close-btn').addEventListener('click', hideSidebar);
    overlay.addEventListener('click', function(e) {
        if (e.target === overlay) {
            hideSidebar();
        }
    });

    // --- Mostra la sidebar ---
    overlay.classList.add('visible');
    sidebar.classList.add('visible');
}

/**
 * Nasconde la sidebar.
 */
function hideSidebar() 
{
    const overlay = document.getElementById('cart-sidebar-overlay');
    const sidebar = document.getElementById('cart-sidebar');
    if (overlay) {
        overlay.classList.remove('visible');
        sidebar.classList.remove('visible');
    }
}



/* RICHIESTA AJAX PER L'AGGIUNTA DI UNA RECENSIONE */


document.getElementById('reviewForm').addEventListener('submit', function(e) {
    e.preventDefault();
    
    // Recupera i dati dal form
    const rating = document.querySelector('input[name="rating"]:checked')?.value;
    const text = document.getElementById('reviewText').value;
    const productId = document.body.getAttribute('data-product-id');
    
    if (!rating) 
    {
        alert('Seleziona una valutazione');
        return;
    }
    
    // Crea l'oggetto FormData per la richiesta
    const params = new URLSearchParams({
        text: text,
        vote: rating,
        IDProdotto: productId
    })


    console.log(text);
    console.log(rating);
    console.log(productId);
    
    // Effettua la richiesta AJAX
    fetch('/IStyle/product?action=AddFeedback&' + params.toString(), {
        method: 'GET',
    })
    .then(response => {
        if (!response.ok) {
            return response.json().then(err => { throw err; });
        }
        return response.json();
    })
    .then(data => {
        if (data.success) 
        {
            // Aggiungi la nuova recensione alla lista
            addReviewToPage(data.data);
            
            // Resetta il form
            document.getElementById('reviewForm').reset();
            document.querySelectorAll('input[name="rating"]').forEach(radio => 
            {
                radio.checked = false;
            });
       
            alert('Recensione inviata con successo!');
        } 
        else 
        {
            alert(data.error || 'Errore nell\'invio della recensione');
        }
    })
    .catch(error => {
        console.error('Error:', error);
        alert(error.message || 'Si è verificato un errore');
    });
});

function addReviewToPage(feedback) {
    const reviewsList = document.getElementById('reviewsList');
    
    // Crea il nuovo elemento recensione
    const reviewItem = document.createElement('div');
    reviewItem.className = 'review-item';
    
    // Crea le stelle in base al voto
    let starsHtml = '';
    let vote = Math.floor(feedback.vote);
    let count = 5;


    for (let i = 0; i < vote; i++) 
    {
        starsHtml += '<i class="fas fa-star"></i>';
        count--;
    }

    for(let i = 0 ; i < count ; i++)
    {
        starsHtml += '<i class="fas fa-star" style= "color: #ddd"></i>';
    }
    // Costruisci l'HTML della recensione
    reviewItem.innerHTML = `
        <div class="review-header">
            <div class="reviewer">${feedback.username}</div>
            <div class="review-date">${feedback.ReviewDate}</div>
        </div>

        <div class="review-rating">
                ${starsHtml}
        </div>

        <p class="review-text">${feedback.text}</p> 
    `;
    
    // Aggiungi la recensione in cima alla lista
    reviewsList.insertBefore(reviewItem, reviewsList.firstChild);
}





















