function validateRegisterForm() {
    const fields = ["Username", "Name", "Surname", "Password", "email"];
    for (let field of fields) {
        if (!document.getElementById("reg-" + field).value.trim()) {
            alert("Per favore compila il campo: " + field);
            return false;
        }
    }
    return true;
}

function validateLoginForm() {
    const fields = ["login-email", "login-Password"];
    for (let field of fields) {
        if (!document.getElementById(field).value.trim()) {
            alert("Per favore compila tutti i campi di login.");
            return false;
        }
    }
    return true;
}

function submitRegistration() {
    if (!validateRegisterForm()) return;

    const data = {
        action: "register",
        Username: document.getElementById("reg-Username").value,
        Name: document.getElementById("reg-Name").value,
        Surname: document.getElementById("reg-Surname").value,
        Password: document.getElementById("reg-Password").value,
        email: document.getElementById("reg-email").value,
        NewsLetterSubscription: document.getElementById("reg-NewsLetterSubscription").checked
    };

    fetch(contextPath() + "/authentication", {
        method: 'POST',
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded'
        },
        body: new URLSearchParams(data)
    })
    .then(response => response.json())
    .then(json => {
        if (json.success) 
        {
            window.location.href = json.redirectURL;
        } 
        else 
        {              
            if(json.error === "email already exsist")
                alert("Errore: L'email è già registrata")
            else if(json.error === "server error")
                alert("Errore del server")
            else if(json.error === "username already exsist")
                alert("Username già registrato")
            else 
                alert("Errore durante la registrazione: Errore sconosciuto");
        }
    })
    .catch(err => alert("Errore di connessione: " + err));
}

function submitLogin() {
    if (!validateLoginForm()) return;

    const data = {
        action: "login",
        email: document.getElementById("login-email").value,
        Password: document.getElementById("login-Password").value
    };

    fetch(contextPath() + "/authentication", {
        method: 'POST',
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded'
        },
        body: new URLSearchParams(data)
    })
    .then(response => response.json())
    .then(json => {
        if (json.success) {
            window.location.href = json.redirectURL;
        } else {
            alert("Errore durante il login: " + (json.error || "Credenziali errate"));
        }
    })
    .catch(err => alert("Errore di connessione: " + err));
}

// Funzione di utilità per determinare il context path dinamicamente
function contextPath() {
    return window.location.pathname.substring(0, window.location.pathname.indexOf("/", 2));
}
