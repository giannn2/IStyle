/*RICHIESTA AJAX PER AGGIUNTA/RIMOZIONE DEL PRODOTTO AI PREFERITI*/

  
document.addEventListener('DOMContentLoaded', () => {
        attachWishlistListeners();
});



function onAddClick(e) {
    const button = e.currentTarget;
    const productId = button.getAttribute("data-id");

    fetch("/IStyle/user/wishlist?action=add&IDProduct=" + productId, {
        method: "POST",
        headers: {
            "Content-Type": "application/x-www-form-urlencoded",
            "X-Requested-With": "XMLHttpRequest"
        }
    })
    .then(response => {
        if (response.status === 401) {
            alert("Devi effettuare il login per aggiungere ai preferiti.");
            window.location.href = "/IStyle/View/Authentication.jsp";
            return Promise.reject("Non autenticato");
        }
        if (!response.ok) {
            return Promise.reject("Errore generico");
        }
        return response.text();
    })
    .then(data => {
        alert("Prodotto aggiunto ai preferiti!");
        // Cambia classe e testo
        button.classList.remove("add-wishlist");
        button.classList.add("remove-wishlist");
        button.textContent = "Rimuovi dai preferiti";

        // Cambia listener: rimuovi onAddClick e aggiungi onRemoveClick
        button.removeEventListener("click", onAddClick);
        button.addEventListener("click", onRemoveClick);
    })
    .catch(error => {
        if (error !== "Non autenticato") {
            alert("Errore nell'aggiunta ai preferiti. Riprova.");
            console.error(error);
        }
    });
}

function onRemoveClick(e) {
    const button = e.currentTarget;
    const productId = button.getAttribute("data-id");

    fetch('/IStyle/user/wishlist?action=remove&IDProduct=' + productId, { method: 'POST' })
    .then(res => {
        if (!res.ok) {
            return Promise.reject("Errore nella risposta del server");
        }
        return res.json();
    })
    .then(data => {
        if (data.success) {
            alert("Prodotto rimosso dai preferiti!");
            // Cambia classe e testo
            button.classList.remove("remove-wishlist");
            button.classList.add("add-wishlist");
            button.textContent = "Aggiungi ai preferiti";

            // Cambia listener: rimuovi onRemoveClick e aggiungi onAddClick
            button.removeEventListener("click", onRemoveClick);
            button.addEventListener("click", onAddClick);
        } else {
            console.log("Errore nella rimozione dai preferiti");
        }
    });
}

function attachWishlistListeners() {
    // Associa gli eventi in base alla classe attuale dei bottoni
    document.querySelectorAll(".add-wishlist").forEach(button => {
        // Rimuovo per sicurezza eventuali duplicati
        button.removeEventListener("click", onAddClick);
        button.addEventListener("click", onAddClick);
    });

    document.querySelectorAll(".remove-wishlist").forEach(button => {
        button.removeEventListener("click", onRemoveClick);
        button.addEventListener("click", onRemoveClick);
    });
}



/*RICHIESTA AJAX PER LA VISUALIZZAZIONE DEI PRODOTTI FILTRATI*/

document.getElementById('filterForm').addEventListener('submit', function(e) {
    e.preventDefault();

    const form = e.target;
    const formData = new FormData(form);
    const params = new URLSearchParams(formData);
    params.append('action', 'Filter');

    fetch('/IStyle/product?' + params.toString())
        .then(res => res.json())
        .then(data => {
            const container = document.querySelector('.products-container');

            if (data.length === 0) {
                container.innerHTML = '<h3>Non ci sono prodotti disponibili</h3>';
                return;
            }

            const products = data.data
            container.innerHTML = products.map(p => `
                <div class="product">
                    <h4>${p.name}</h4>
                    <p>Prezzo: €${p.price.toFixed(2)}</p>
                    <a href="/IStyle/product/${p.name}">Details</a>
                    <button class="AddToCart" data-id="${p.id}">Add To Cart</button>
                    <button class="wishlist-btn ${p.isInWishList ? 'remove-wishlist' : 'add-wishlist'}" data-id="${p.id}">
                        ${p.isInWishList ? 'Rimuovi dai preferiti' : 'Aggiungi ai preferiti'}
                    </button>
                </div>
            `).join('');

            // Re-associa gli event listener dopo il refresh dell'HTML
            attachWishlistListeners();
        });
});



/*RICHIESTA AJAX PER FUNZIONE DI RICERCA ADATTIVA*/

document.getElementById('searchInput').addEventListener("input", function(inputBox) {

    const parameterForQuery = inputBox.target.value;
    if(parameterForQuery && parameterForQuery.trim() != "")
    {
        fetch("/IStyle/product?action=Search&name=" + parameterForQuery)
        .then(res => res.json())
        .then(data => 
        {   
            const resultsDiv = document.getElementById("autocompleteResults");
            resultsDiv.innerHTML = ""; // Pulisci risultati precedenti


            data.data.forEach(product => 
            {
                const div = document.createElement("div");
                div.textContent = product.name; // Adatta al campo giusto (es. .nome, .titolo ecc.)
                div.classList.add("autocomplete-item"); // Classe CSS opzionale per stile

                div.addEventListener('click', function(){
                    document.getElementById('searchInput').value = product.name;
                    resultsDiv.innerHTML = ' ';
                })


                resultsDiv.appendChild(div);
            });
        })
    }
    else
    {
        document.getElementById("autocompleteResults").innerHTML = "";
    }
})


/*RICHIESTA AJAX PER AGGIUNTA DEL PRODOTTO AL CARRELLO*/


document.querySelectorAll(".AddToCart").forEach(link => {
    link.addEventListener("click", function(e)
    {
        const id = e.target.dataset.id;
        fetch(("/IStyle/cart?action=add&id=" + id))
        .then(res => res.json())
        .then(data => {
            console.log("Prodotto aggiunto al carrello", data);
        })
    })
})



