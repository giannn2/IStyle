src="https://cdn.jsdelivr.net/npm/tsparticles@2">
    // Inizializzazione tsParticles
    
tsParticles.load("tsparticles", {
    fpsLimit: 60,
    particles: {
        number: { value: 80, density: { enable: true, area: 800 } },
        color: { value: "#E75919" },
        shape: { type: "circle" },
        opacity: { value: 0.6, random: true },
        size: { value: { min: 2, max: 5 }, random: true },
        move: {
            enable: true,
            speed: 1.5,
            direction: "none",
            outModes: { default: "bounce" }
        },
        links: {
            enable: true,
            distance: 120,
            color: "#ffffff",
            opacity: 0.2,
            width: 1
        }
    },
    interactivity: {
        detectsOn: "canvas",
        events: {
            onHover: { enable: true, mode: "grab" },
            onClick: { enable: true, mode: "push" },
            resize: true
        },
        modes: {
            grab: { distance: 140, links: { opacity: 0.5 } },
            push: { quantity: 4 }
        }
    },
    detectRetina: true
});

// Rimuovi dalla wishlist
document.querySelectorAll('.remove-item-btn').forEach(btn => {
    btn.addEventListener('click', function() {
        const item = this.closest('.wishlist-item');
        item.style.opacity = '0';
        item.style.transform = 'translateX(-20px)';
        setTimeout(() => {
            item.remove();
            checkEmptyWishlist();
        }, 300);
    });
});

function checkEmptyWishlist() {
    const items = document.querySelectorAll('.wishlist-items .wishlist-item');
    if (items.length === 0) {
        document.querySelector('.wishlist-items').style.display = 'none';
        document.getElementById('empty-wishlist').style.display = 'block';
    }
}

