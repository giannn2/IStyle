//RICHIESTA AJAX PER I DATI DEL CARRELLO MODALE




//RICHIESTA AJAX PER OTTENERE I DATI PER IL CARRELLO MODALE

function fetchProductModalData(productId, color) {
    return new Promise((resolve, reject) => {
        const contextPath = document.body.dataset.contextPath;
        const url = `${contextPath}/product?action=selectProductData&IDProdotto=${productId}&Color=${encodeURIComponent(color)}`;
        
        fetch(url, {
            method: 'GET',
            headers: {
                'Accept': 'application/json'
            }
        })
        .then(response => {
            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }
            return response.json();
        })
        .then(data => {
            if (data.success) {
                resolve(data.data); // Risolve con i dati del prodotto
            } else {
                reject(new Error(data.message || 'Errore nel recupero dei dati del prodotto'));
            }
        })
        .catch(error => {
            console.error('Errore nella richiesta:', error);
            showAlert('Si è verificato un errore nel recupero dei dati del prodotto', 'error');
            reject(error);
        });
    });
}


/*RICHIESTA AJAX PER AGGIUNTA DEL PRODOTTO AL CARRELLO*/
function addToCart() 
{
    const modal = document.getElementById('modaleCarrello');
    const productId = modal.dataset.productId;
    const color = modal.dataset.selectedColor;
    const model = document.getElementById('model-select').value;
    
    if (!model) {
        showAlert('Seleziona un modello prima di confermare', 'warning');
        return;
    }

    const confirmBtn = document.querySelector('.confirm-btn');
    // Mostra lo stato di caricamento
    confirmBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Aggiungendo...';
    confirmBtn.disabled = true;

    const contextPath = document.body.dataset.contextPath;
    const url = `${contextPath}/cart?action=add&id=${encodeURIComponent(productId)}&color=${encodeURIComponent(color)}&model=${encodeURIComponent(model)}`;

    fetch(url, {
        method: 'GET',
        headers: {
            'Accept': 'application/json'
        }
    })
    .then(response => {
        if (!response.ok) {
            throw new Error('Network response was not ok');
        }
        return response.json();
    })
    .then(data => {
        if (data.success) {
            showAlert('Prodotto aggiunto al carrello', 'success');
            chiudiModale();
            
            // Puoi aggiornare il contatore del carrello qui se necessario
            // updateCartCounter(data.data.quantityOfProductInCart);
        } else {
            throw new Error(data.message || 'Errore durante l\'aggiunta al carrello');
        }
    })
    .catch(error => {
        console.error('Error:', error);
        showAlert(error.message || 'Si è verificato un errore', 'error');
    })
    .finally(() => {
        confirmBtn.innerHTML = 'Conferma';
        confirmBtn.disabled = false;
    });
}



// Richiesta AJAX per aggiungere il prodotto alla lista dei preferiti
async function addToWishlist(btn) {
    const contextPath = document.querySelector('body').dataset.contextPath;
    const productId = btn.dataset.productId;
    const cuore = btn.querySelector('.cuore-icon');

    try {
        const response = await fetch(`${contextPath}/user/wishlist?action=add`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
                'X-Requested-With': 'XMLHttpRequest'
            },
            body: `IDProduct=${productId}`
        });

        const result = await response.json();

        if (result.success) {
            cuore.src = `${contextPath}/images/icons/red-heart.png`;
            showAlert("Prodotto aggiunto ai preferiti!", "success");
        } else {
            showAlert(result.error || "Errore durante l'aggiunta", "error");
        }
    } catch (error) {
        showAlert("Errore di connessione", "error");
        console.error("Errore AJAX:", error);
    }
}

//Richiesta AJAX per rimuovere il prodotto alla lista dei preferiti
async function removeFromWishlist(btn) {
    const contextPath = document.querySelector('body').dataset.contextPath;
    const productId = btn.dataset.productId;
    const cuore = btn.querySelector('.cuore-icon');

    try {
        const response = await fetch(`${contextPath}/user/wishlist?action=remove`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
                'X-Requested-With': 'XMLHttpRequest'
            },
            body: `IDProduct=${productId}`
        });

        const result = await response.json();

        if (result.success) {
            cuore.src = `${contextPath}/images/icons/heart-icon.png`;
            showAlert("Prodotto rimosso dai preferiti!", "success");
        } else {
            showAlert(result.message || "Errore durante la rimozione", "error");
        }
    } catch (error) {
        showAlert("Errore di connessione", "error");
        console.error("Errore AJAX:", error);
    }
}

