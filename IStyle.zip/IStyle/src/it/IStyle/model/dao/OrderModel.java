package it.IStyle.model.dao;

import java.sql.Statement;
import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;
import java.util.LinkedList;
import it.IStyle.model.bean.Order;
import it.IStyle.model.bean.ProductBean;

public class OrderModel 
{
    private static DataSource ds;

	static 
    {
		try 
        {
			Context initCtx = new InitialContext();
			Context envCtx = (Context) initCtx.lookup("java:comp/env");

			ds = (DataSource) envCtx.lookup("jdbc/istyledb");

		}
        catch (NamingException e) 
        {
			System.out.println("Error:" + e.getMessage());
		}
	}

	private static final String TABLE_NAME = "ordine";


	private synchronized boolean associateOrderToUser(String username, int IDOrdine) throws SQLException
	{
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		String query = "INSERT INTO effettua (Username,IDOrdine) VALUES(?,?)";
		int AffectedRows = 0;

		try
		{
			connection = OrderModel.ds.getConnection();
			preparedStatement = connection.prepareStatement(query);
			preparedStatement.setString(1, username);
			preparedStatement.setInt(2, IDOrdine);
			AffectedRows = preparedStatement.executeUpdate();
		}
		finally
		{
			try
			{
				if(preparedStatement != null)	
					preparedStatement.close();
			}
			finally
			{
				if(connection != null)
					connection.close();
			}
		}



		return (AffectedRows != 0);
	}	

	private synchronized boolean associateProductsToOrder(int IDOrdine, LinkedList<ProductBean> products) throws SQLException
	{
		//Si deve comporre una query aggiungendo X stringhe di VALUES per la insert per qunti sono i prodotti. L'ID ordine è uguale in tutti i casi, cambia solo l'id del prodotto.
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		String query = "INSERT INTO contiene (IDProdotto, IDOrdine, Quantita,colore,modello) VALUES ";
		int AffectedRows = 0;


		for(int i = 0 ; i < products.size() ; i++)
			query += "(?,?,?,?,?), ";
		
		query = query.substring(0, query.length() - 2); //Per rimuovere la virgola

		try
		{
			connection = OrderModel.ds.getConnection();
			preparedStatement = connection.prepareStatement(query);

			int paramIndex = 1;
			for(ProductBean p : products)
			{
				preparedStatement.setInt( paramIndex++ , p.getID());
				preparedStatement.setInt( paramIndex++ , IDOrdine);
				preparedStatement.setInt( paramIndex++ , p.getQuantityInCart());
				preparedStatement.setString( paramIndex++ , p.getColor());
				preparedStatement.setString( paramIndex++ , p.getModel());
			}

			AffectedRows = preparedStatement.executeUpdate();
		}
		finally
		{
			try
			{
				if(preparedStatement != null)
					preparedStatement.close();
			}
			finally
			{
				if(connection != null)
					connection.close();
			}
		}

		return (AffectedRows != 0);

	}

	private synchronized LinkedList<ProductBean> doRetrieveProductsInOrder(int IDOrdine) throws SQLException
	{
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		String query = "SELECT p.IDProdotto, p.Costo, p.Nome, p.Categoria,p.Descrizione,p.personalizzabile, c.colore, c.modello" +
					   " FROM prodotto p JOIN contiene c ON p.IDProdotto = c.IDProdotto" +
					   " WHERE c.IDOrdine = ?";
		
		LinkedList<ProductBean> productsInOrder = new LinkedList<ProductBean>();

		try
		{
			connection = OrderModel.ds.getConnection();
			preparedStatement = connection.prepareStatement(query);
			preparedStatement.setInt(1, IDOrdine);
			ResultSet rs = preparedStatement.executeQuery();
			ProductBean product;

			while(rs.next())
			{
				product = new ProductBean();
				product.setID(rs.getInt("IDProdotto"));
				product.setCategory(rs.getString("Categoria"));
				product.setName(rs.getString("Nome"));
				product.setPrice(rs.getBigDecimal("Costo").doubleValue());
				product.setDescription(rs.getString("Descrizione"));
				product.setCustomizable(rs.getBoolean("personalizzabile"));
				product.setColor(rs.getString("colore"));
				product.setModel(rs.getString("modello"));
				productsInOrder.add(product);
			}
		}
		finally
		{
			try
			{
				if(preparedStatement != null)
					preparedStatement.close();
			}
			finally
			{
				if(connection != null)
					connection.close();
			}
		}

		return productsInOrder;
	}




	public synchronized int doSave(Order order, String username) throws SQLException //Salva l'ordine nel DB completamente (associando i valori anche nelle tabelle al di fuori di quella dell'ordine) e restituisce l'ID dell'ordine appena inserito, 0 se fallisce nell'inserimento
	{
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		String query = "INSERT INTO " + OrderModel.TABLE_NAME + " (DataErogazione,DataConsegna,MetodoDiSpedizione,ImportoTotale,DataEmissione,TipoPagamento,Stato,IndirizzoSpedizione,paymentIntent) VALUES(?,?,?,?,?,?,?,?,?)";
		int IDOrdine = 0;
		try
		{	
			connection = OrderModel.ds.getConnection();

			//Inserimento dell'ordine
			preparedStatement = connection.prepareStatement(query, Statement.RETURN_GENERATED_KEYS);
			preparedStatement.setDate(1, order.getDataErogazione());
			preparedStatement.setDate(2, order.getDataConsegna());
			preparedStatement.setString(3, order.getMetodoDiSpedizione());
			preparedStatement.setBigDecimal(4, BigDecimal.valueOf(order.getImportoTotale()));
			preparedStatement.setDate(5, order.getDataEmissione());
			preparedStatement.setString(6, order.getTipoPagamento());
			preparedStatement.setString(7, order.getStato()); 
			preparedStatement.setString(8, order.getIndirizzoDiSpedizione());
			preparedStatement.setString(9, order.getPaymentIntentID());

			//Stati possibili dell'ordine : Elaborazione , Spedito , Ricevuto

			if(preparedStatement.executeUpdate() > 0)  //Se l'inserimento dell'ordine va a buon fine 
			{
				//Associamo l'ordine all'utente
				ResultSet rs = preparedStatement.getGeneratedKeys(); //Restituisce i dati generati dal DB con l'operazione di UPDATE (quelli inseriti nella tabella in questo caso)
				if(rs.next())
				{
					IDOrdine = rs.getInt(1);
					if(associateOrderToUser(username,IDOrdine)) //Se riusciamo ad associare l'ordine allo user
					{
						//Procediamo con associare i prodotti all'ordine.
						associateProductsToOrder(IDOrdine, order.getProductsInOrder());
					}
				}
			}
		}
		finally
		{
			try
			{
				if(preparedStatement != null)
					preparedStatement.close();
			}
			finally
			{
				if(connection != null)
					connection.close();
			}
		}

		return IDOrdine;
	}

	public synchronized boolean doDelete(int IDOrdine) throws SQLException
	{
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		String query = "DELETE FROM " + OrderModel.TABLE_NAME + " WHERE IDOrdine = ?";
		int AffectedRows = 0;

		try
		{
			connection = OrderModel.ds.getConnection();
			preparedStatement = connection.prepareStatement(query);
			preparedStatement.setInt(1, IDOrdine);
			AffectedRows = preparedStatement.executeUpdate();
		}
		finally
		{
			try
			{
				if(preparedStatement != null)
					preparedStatement.close();
			}
			finally
			{
				if(connection != null)
					connection.close();
			}
		}
		

		return (AffectedRows != 0);
	}



	public synchronized LinkedList<Order> doRetrieveUserOrders(String Username) throws SQLException
	{
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		String query = "SELECT O.IDOrdine, O.DataErogazione, O.DataConsegna, O.MetodoDiSpedizione,O.ImportoTotale,O.DataEmissione, O.TipoPagamento, O.Stato, O.IndirizzoSpedizione,O.paymentIntent" +
						" FROM ordine O JOIN effettua E ON O.IDOrdine = E.IDOrdine" + 
						" WHERE Username = ?";

		LinkedList<Order> orders = new LinkedList<Order>();

		try
		{
			connection = OrderModel.ds.getConnection();
			preparedStatement = connection.prepareStatement(query);
			preparedStatement.setString(1, Username);
			ResultSet rs = preparedStatement.executeQuery();
			Order order;

			while(rs.next())
			{	
				order = new Order();
				order.setIDOrdine(rs.getInt("IDOrdine"));
				order.setDataErogazione(rs.getDate("DataErogazione"));;
				order.setDataConsegna(rs.getDate("DataConsegna"));
				order.setMetodoDiSpedizione(rs.getString("MetodoDiSpedizione"));
				order.setImportoTotale(rs.getInt("ImportoTotale"));
				order.setDataEmissione(rs.getDate("DataEmissione"));
				order.setTipoPagamento((rs.getString("TipoPagamento")));
				order.setStato(rs.getString("Stato"));
				order.setIndirizzoDiSpedizione(rs.getString("IndirizzoSpedizione"));
				order.setProductsInOrder(doRetrieveProductsInOrder(order.getIDOrdine()));
				order.setPaymentIntentID(rs.getString("paymentIntent"));
				orders.add(order);
			}
		}
		finally
		{
			try
			{
				if(preparedStatement != null)
					preparedStatement.close();
			}
			finally
			{
				if(connection != null)
					connection.close();
			}
		}
			
		
		
		return orders;
	}


    public synchronized boolean hasUserPlacedOrder(String username, int IDOrdine) throws SQLException
	{
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		String query = "SELECT * FROM effettua WHERE Username = ? AND IDOrdine = ?";
		boolean check = false;

		try
		{
			connection = OrderModel.ds.getConnection();
			preparedStatement = connection.prepareStatement(query);
			preparedStatement.setString(1, username);
			preparedStatement.setInt(2, IDOrdine);
			ResultSet rs = preparedStatement.executeQuery();

			if(rs.next())
				check = true;
		}	
		finally
		{
			try
			{
				if(preparedStatement != null)
					preparedStatement.close();
			}
			finally
			{
				if(connection != null)
					connection.close();
			}
		}

		return check;
	}


	public synchronized Order doRetrieveByPaymentIntent(String paymentIntentID) throws SQLException
	{
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		String query = "SELECT * FROM " +  OrderModel.TABLE_NAME + " WHERE paymentIntent = ?";
		Order order = null;
		
		try
		{
			connection = OrderModel.ds.getConnection();
			preparedStatement = connection.prepareStatement(query);
			preparedStatement.setString(1, paymentIntentID);
			ResultSet rs = preparedStatement.executeQuery();

			if(rs.next())
			{
				order = new Order();
				order.setIDOrdine(rs.getInt("IDOrdine"));
				order.setDataErogazione(rs.getDate("DataErogazione"));;
				order.setDataConsegna(rs.getDate("DataConsegna"));
				order.setMetodoDiSpedizione(rs.getString("MetodoDiSpedizione"));
				order.setImportoTotale(rs.getInt("ImportoTotale"));
				order.setDataEmissione(rs.getDate("DataEmissione"));
				order.setTipoPagamento((rs.getString("TipoPagamento")));
				order.setStato(rs.getString("Stato"));
				order.setIndirizzoDiSpedizione(rs.getString("IndirizzoSpedizione"));
				order.setProductsInOrder(doRetrieveProductsInOrder(order.getIDOrdine()));
				order.setPaymentIntentID(rs.getString("paymentIntent"));
			}
		}
		finally
		{
			try
			{
				if(preparedStatement != null)
					preparedStatement.close();
			}
			finally
			{
				if(connection != null)
					connection.close();
			}
		}


		return order;
	}





}
