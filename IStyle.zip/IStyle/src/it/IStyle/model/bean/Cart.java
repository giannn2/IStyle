package it.IStyle.model.bean;

import java.util.*;



public class Cart 
{
    LinkedList<ProductBean> ProductsList;
    public double totale;


    public Cart()
    {
        this.ProductsList = new LinkedList<ProductBean>();
        this.totale = 0.0;
    }

    public void addCart(ProductBean product)
    {
        this.ProductsList.add(product);
    }

    public void deleteProduct(ProductBean product)
    {
        this.ProductsList.remove(product);
    }

    public ProductBean getProductByID(int ID)
    {   
        ProductBean product = null;
        for(ProductBean p : this.ProductsList)
        {
            if(p.getID() == ID)
                product = p;
        }

        return product;
    }

    public boolean contains(int ID)
    {
        boolean result = false;
        for(ProductBean p : this.ProductsList)
        {
            if(p.getID() == ID)
            {
                result = true;
                break;
            }
        }

        return result;
    }

    public double getTotal()
    {
        this.totale = 0.0;
        for(ProductBean p : this.ProductsList)
            totale += p.getPrice() * p.getQuantityInCart();
        
        return totale;
    }

    public int getQuantityOfProducts() 
    {
        return this.ProductsList.size();
    }

    public LinkedList<ProductBean> getProducts()
    {
        return this.ProductsList;

    }
}
