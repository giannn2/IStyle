package it.IStyle.model.bean;

import java.io.Serializable;
import java.util.*;

public class ProductBean implements Serializable 
{

    private static final long serialVersionUID = 1L;

    private int id;
    private String name;
    private double price;
    private String description;
    private String category;
    private boolean customizable;
    private String color;
    private String model;
    private HashSet<String> avaibleColors;
    private HashSet<String> avaibleModels;


    private LinkedList<String> ImagesPaths;

    private int quantityInCart;
    private boolean isInWishList;


    public ProductBean()
    {
        this.quantityInCart = 0;
        this.isInWishList = false;
    }


    //metodi get

    public String getCategory() { return category; }
    public int getID() { return id; }
    public String getName() { return name; }
    public double getPrice() { return price; }
    public String getDescription() { return description; }
    public LinkedList<String> getImagesPaths() { return this.ImagesPaths; }
    public int getQuantityInCart() { return this.quantityInCart; }
    public boolean getCustomizable(){return this.customizable;}
    public boolean isInWishList(){return this.isInWishList;}
    public HashSet<String> getAvaibleColors() {return this.avaibleColors;}
    public HashSet<String> getAvaibleModels() {return this.avaibleModels;}
    public String getColor() {return this.color;}
    public String getModel() {return this.model;}

    //metodi set

    public void setID(int id) { this.id = id; }
    public void setName(String name) { this.name = name; }
    public void setPrice(double price) { this.price = price; }
    public void setDescription(String description) { this.description = description; }
    public void setCategory (String category) { this.category = category; }
    public void setImagesPaths(LinkedList<String> paths) {this.ImagesPaths = paths;}
    public void setQuantityInCart(int q) {this.quantityInCart = q;}
    public void setCustomizable(boolean value){this.customizable = value;}
    public void setIsInWishList(boolean value){this.isInWishList = value;}
    public void setAvaibleColors(HashSet<String> colors){this.avaibleColors = colors;}
    public void setAvaibleModels(HashSet<String> models){this.avaibleModels = models;}
    public void setColor(String c){this.color = c;}
    public void setModel(String m){this.model = m;}

    @Override
    public String toString() 
    {
        return "\nCodice di questo prodotto è: " + this.id
                + " \nNome: " + this.name
                + " \nPrezzo: " + this.price
                + " \nDescrizione: " + this.description 
		        + " \nCategoria :" + this.category;
    }

    @Override
	public boolean equals(Object o)
	{
		if( o == null )
			return false;
		
		if( o.getClass() != this.getClass() )
			return false;
		
        ProductBean p = (ProductBean) o;
		
		return p.getID() == this.getID();
	}
}

